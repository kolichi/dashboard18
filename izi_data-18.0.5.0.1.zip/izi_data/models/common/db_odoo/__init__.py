# -*- coding: utf-8 -*-
# Copyright 2022 IZI PT Solusi Usaha Mudah

from . import izi_data_source_db_odoo
from . import izi_table_db_odoo
from . import izi_analysis_db_odoo

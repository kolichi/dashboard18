## IZI Data
- **Technical Name**: izi_data
- **Version**: 18.0.5.0.1
- **Author**: IZI PT Solusi Usaha Mudah
- **License**: OPL-1
- **Application**: True

## Credit(s)
### Icon
- Icon made by _`<author>`_ from _`<source>`_

### Contributor
- Gharta Hadisa Halim <[gharta@iziapp.id](mailto:gharta@iziapp.id)>

### Maintainers
This module is maintained by the [IZI PT Solusi Usaha Mudah](https://iziapp.id).

![alt text](static/description/images/izi-logo.png "IZI PT Solusi Usaha Mudah")